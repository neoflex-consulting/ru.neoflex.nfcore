package ru.neoflex.nfcore.utils

class Calc {
        static add(Integer a, Integer b) {
        a+b
    }
}