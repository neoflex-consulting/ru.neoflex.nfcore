
package scripts.utils

import org.slf4j.Logger
import org.slf4j.LoggerFactory
import ru.neoflex.nfcore.base.util.DriverShim
import java.sql.Connection
import java.sql.DriverManager
import com.orientechnologies.orient.core.db.ODatabaseRecordThreadLocal

class JDBC {
    private static final Logger logger = LoggerFactory.getLogger(JDBC.class);

    def static Connection connect(String driverClassName, String url, String userName, String password) {
        DriverShim.registerDriver(driverClassName)
        Connection jdbcConnection = DriverManager.getConnection(url, userName, password)
        logger.info("Connected to " + url)
        return jdbcConnection
    }
    
    def static List<Map<String, String>> select(Connection conn, String sql) {
        def rawData = []
        try {
            def st = conn.createStatement()
            try {
                def rs = st.executeQuery(sql)  
                try {
                    def columnCount = rs.metaData.columnCount
                    while (rs.next()) {
                        def map = [:]
                        for (int i = 1; i <= columnCount; ++i) {
                            def object = rs.getObject(i)
                            map["${rs.metaData.getColumnName(i)}"] = (object == null ? null : object.toString())
                        }
                        rawData.add(map)
                    }
                }
                finally {
                    rs.close()
                }
            }
            finally {
                st.close()
            }
        }
        finally {
            conn.close()
        }
        return rawData
    }
    
    def static List<Map<String, String>> query(String driverClassName, String url, String userName, String password, String sql) {
        def currentDB = ODatabaseRecordThreadLocal.instance().getIfDefined();
        try {
            def conn = connect(driverClassName, url, userName, password)
            try {
                return select(conn, sql)
            }
            finally {
                conn.close()
            }
        }
        finally {
            if (currentDB != null) {
                ODatabaseRecordThreadLocal.instance().set(currentDB);
            }             
        }
    }
}
