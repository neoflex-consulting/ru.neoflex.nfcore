import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def testSetId = "1"
def reportDate = "2020-03-31"
def branch = "000001"*/

if (testSetId != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(testSetId)  
    println(reportDate)       
    println(branch)    
    def conn = jc.connect()
    try {
        def st = conn.createStatement()
        try {
            def rs = st.execute("""SELECT dqc.data_quality_runTestSet( 
'${testSetId}',
date '${reportDate}',
date '${reportDate}',
'${branch}',
  null,
  null,
  0
);""")
        }
        finally {
            st.close()
        }
    }
    finally {
        conn.close()
    }
}
return []