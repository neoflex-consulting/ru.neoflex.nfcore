import ru.neoflex.nfcore.base.components.SpringContext
import ru.neoflex.nfcore.masterdata.services.MasterdataProvider
import org.springframework.beans.factory.NoSuchBeanDefinitionException

try {
    def provider = SpringContext.getBean(MasterdataProvider.class)
    if(provider) provider.activateAllEntityTypes()
}
catch (NoSuchBeanDefinitionException e) {
}
