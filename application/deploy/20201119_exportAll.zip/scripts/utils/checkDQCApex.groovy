import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection


def okTextColor = "rgb(14, 90, 125)"
def errorTextColor = "rgb(173, 20, 87)"

def okFillColor = "rgb(240, 254, 255)"
def errorFillColor = "rgb(248, 241, 243)"

def contentBox = '<div style="height: 40px; padding: 0 16px; margin: 0 16px 0 16px; box-shadow: -2px -2px 4px rgba(0, 0, 0, 0.05), 2px 2px 4px rgba(0, 0, 0, 0.1); border-radius: 4px; display: flex !important; align-items: center !important; font-family: Roboto !important; font-weight: 400 !important; font-size: 14px !important; background-color: <FILL_COLOR>; color: <TEXT_COLOR>"><CONTENT></div>';
def okPlaceholder = """<div style="display: flex; margin: 0px 12px 0px 0px; cursor: pointer;"><svg style="margin: auto 12px auto 0;" width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C17.5275 2 22 6.47293 22 12C22 17.5275 17.5271 22 12 22C6.47254 22 2 17.5271 2 12C2 6.47254 6.47297 2 12 2ZM12 20.4375C16.6638 20.4375 20.4375 16.6635 20.4375 12C20.4375 7.33621 16.6635 3.5625 12 3.5625C7.33621 3.5625 3.5625 7.33652 3.5625 12C3.5625 16.6638 7.33656 20.4375 12 20.4375ZM12 10.3723C12.4315 10.3723 12.7812 10.722 12.7812 11.1535V16.1845C12.7812 16.616 12.4315 16.9657 12 16.9657C11.5685 16.9657 11.2188 16.6159 11.2188 16.1844V11.1535C11.2188 10.722 11.5685 10.3723 12 10.3723ZM10.9453 8.36096C10.9453 8.94345 11.4175 9.41565 12 9.41565C12.5825 9.41565 13.0547 8.94345 13.0547 8.36096C13.0547 7.77847 12.5825 7.30627 12 7.30627C11.4175 7.30627 10.9453 7.77847 10.9453 8.36096Z" fill="${okTextColor}"/></svg><DQC_TEXT></div>""";
def errorPlaceholder = """<div style="display: flex; margin: 0px 12px 0px 0px; cursor: pointer;"><svg style="margin: auto 12px auto 0;" width="16" height="16" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47254 2 2 6.47293 2 12C2 17.5275 6.47293 22 12 22C17.5275 22 22 17.5271 22 12C22 6.47254 17.5271 2 12 2ZM12 20.4375C7.33621 20.4375 3.5625 16.6635 3.5625 12C3.5625 7.33621 7.33652 3.5625 12 3.5625C16.6638 3.5625 20.4375 7.33652 20.4375 12C20.4375 16.6638 16.6635 20.4375 12 20.4375ZM12 7.03415C11.5685 7.03415 11.2188 7.38391 11.2188 7.8154V12.8464C11.2188 13.2779 11.5685 13.6276 12 13.6276C12.4315 13.6276 12.7812 13.2779 12.7812 12.8464V7.8154C12.7812 7.38391 12.4315 7.03415 12 7.03415ZM13.0547 15.6392C13.0547 16.2217 12.5825 16.6939 12 16.6939C11.4175 16.6939 10.9453 16.2217 10.9453 15.6392C10.9453 15.0567 11.4175 14.5845 12 14.5845C12.5825 14.5845 13.0547 15.0567 13.0547 15.6392Z" fill="${errorFillColor}"/></svg><DQC_TEXT></div>""";



/*def reportDate = "2019-04-01"*/

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRDemo'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
def conn = jc.connect()
try {
    def st = conn.createStatement()
    try {
        def rs = st.executeQuery("""select nrapp.APEX_NR_UTIL.getApexDqcMessage
                (
                        i_ReportId    => 11100,
                        i_OnDate      => to_date('${reportDate}','YYYY-MM-DD') - 1,
                        i_AppId       => 11100,
                        i_PageId      => 79,
                        i_CallerPage  => 2,
                        i_SessionId   => '',
                        i_Debug       => '',
                        i_PicturePath => '/images/'
                ) as ApexDqcMessage
                from dual""")
        try {
            def rowData = []
			def returnMap = [:]
            while (rs.next()) {
                def map = [:]
                def columnCount = rs.metaData.columnCount
                for (int i = 1; i <= columnCount; ++i) {
                    def object = rs.getObject(i)
                    def text = (object == null ? null : object.toString().replace("<img src=\"/images/Success-icon.png\" width=\"30\" height=\"22\">",""))
                    def isError = text != " Ошибки ПККД отсутствуют."
                    map["${rs.metaData.getColumnName(i)}"] = isError 
                    ? contentBox.replace("<CONTENT>",okPlaceholder).replace("<FILL_COLOR>", errorFillColor).replace("<TEXT_COLOR>", errorTextColor).replace("<DQC_TEXT>",text) 
                    : contentBox.replace("<CONTENT>",okPlaceholder).replace("<FILL_COLOR>", okFillColor).replace("<TEXT_COLOR>", okTextColor).replace("<DQC_TEXT>",text)
                }
                returnMap = map
            }
            return returnMap
        }
        finally {
            rs.close()
        }
    }
    finally {
        st.close()
    }
}
finally {
    conn.close()
}