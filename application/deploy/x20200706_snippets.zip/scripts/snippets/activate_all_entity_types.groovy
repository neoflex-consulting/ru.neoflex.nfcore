import ru.neoflex.nfcore.base.components.SpringContext
import ru.neoflex.nfcore.masterdata.services.MasterdataProvider

def provider = SpringContext.getBean(MasterdataProvider.class)
provider.activateAllEntityTypes()
