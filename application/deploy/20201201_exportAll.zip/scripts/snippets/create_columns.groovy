import ru.neoflex.nfcore.base.auth.AuthPackage
import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DataType
import ru.neoflex.nfcore.dataset.DatasetFactory
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.GroovyDataset
import groovy.json.JsonOutput

    def resource = DocFinder.create(Context.current.store, DatasetPackage.Literals.GROOVY_DATASET, [name: 'GroovyDatasetUsers'])
                .execute().resourceSet
    if (!resource.resources.empty) {

        Object[] resultSet = AuthPackage.Literals.USER.eAllStructuralFeatures.name

        def metaDatasetRef = Context.current.store.getRef(resource.resources.get(0))
        def metaDataset = resource.resources.get(0).contents.get(0) as GroovyDataset
        if (resultSet != null) {
            for (int i = 0; i < resultSet.length; ++i) {

                def datasetColumn = DatasetFactory.eINSTANCE.createDatasetColumn()
                datasetColumn.rdbmsDataType = DataType.STRING
                datasetColumn.convertDataType = DataType.STRING
                datasetColumn.name = resultSet[i]
                metaDataset.datasetColumn.each { c->
                    if (c.name == resultSet[i]) {
                        throw new IllegalArgumentException("Column " + resultSet[i] + " already exists")
                    }
                }
                metaDataset.datasetColumn.add(datasetColumn)
            }
            Context.current.store.updateEObject(metaDatasetRef, metaDataset)
            return JsonOutput.toJson("created columns, count: " + metaDataset.datasetColumn.size())
            println("created columns, count: " + metaDataset.datasetColumn.size())
        }
    }