import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectiontING'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
def conn = jc.connect()
try {
    def st = conn.createStatement()
    try {
        def rs = st.executeQuery("""select count(1) as branches
  from dma.dm_branch_d t
 where sysdate between t.data_actual_date and t.data_actual_end_date
   and t.branch_rk not in (0, -1)
   and t.branch_code not in (nrsettings.settings_tools.getParamChrValue('HEAD_OFFICE_BRANCH_CODE'))""")
        try {
            def rowData = []
            while (rs.next()) {
                def map = [:]
                def columnCount = rs.metaData.columnCount
                for (int i = 1; i <= columnCount; ++i) {
                    def object = rs.getObject(i)
                    map["${rs.metaData.getColumnName(i)}"] = (object == null ? null : object.toString())
                }
                rowData.add(map)
            }
            return rowData[0]["BRANCHES"]
        }
        finally {
            rs.close()
        }
    }
    finally {
        st.close()
    }
}
finally {
    conn.close()
}