import scripts.utils.JDBC
def rowData = JDBC.query(
    "com.orientechnologies.orient.jdbc.OrientJdbcDriver", 
    "jdbc:orient:remote:localhost/masterdata", 
    "admin", "admin", 
    "select from Person")
rowData.forEach {println(it)}