import ru.neoflex.meta.emfgit.Transaction
import java.nio.file.Files
import java.io.File
import ru.neoflex.nfcore.base.components.SpringContext
import ru.neoflex.nfcore.masterdata.services.MasterdataProvider

def importMasterData(String tableName) {
    def provider = SpringContext.getBean(MasterdataProvider.class);
    def data = Transaction.getCurrent().getFileSystem().getPath("/masterdata/${tableName}.json")
    def is = Files.newInputStream(data)
    try {
        provider.execute("delete from ${tableName}")
        def exporter = provider.createExporter()
        print tableName + ":"
        println exporter.importJson(is)
    }
    finally {
        is.close()
    }
}

importMasterData("F110_BalAccountClassifier")
importMasterData("F110_AccountIncludeExcludeClassifier")
