import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection
import java.text.SimpleDateFormat;
import java.util.Calendar;

def format = new SimpleDateFormat("yyyy-MM-dd")

/*def formatName = "F115_KLIKO_53"
def formNumber = "0409115"
def formType = "M"
def branchRk = "1";
def reportDate = "2020-03-31"*/

def date = format.parse(reportDate)
def Calendar c = Calendar.getInstance();
c.setTime(date);
c.add(Calendar.DATE, -1)
def reportDateMinusOne = format.format(c.getTime());

if (reportDate != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(reportDate)       
    println(branchRk)    
    def conn = jc.connect()
    try {
        def st = conn.createStatement()
        try {
            def rs = st.execute("""select data_representation.export_util_pLoadSQLtoBLOB(
    i_type_format_name             :='${formatName}',
    i_file_name                    :='${formNumber}_kliko_${reportDateMinusOne}.txt',
    i_raise_if_data_error          :=1,
    i_parent_event_record_id       :=null,
    i_sql_text                     :='',
    i_list_pairs_values            :='i_OnDate=>date ''${reportDateMinusOne}'';i_BranchRk=>${branchRk};i_FormType=>''${formType}''',
    i_delimeter_left_and_rigth     :='=>',
    i_delimeter_pairs              :=';',
    i_execute                      :=1,
    i_detail_log                   :=1,
    i_flag_compress_blob           :=0,
    i_rows_in_file                 :=0,
    i_file_body_prefix             :='',
    i_file_body_postfix            :=''
)""")
        }
        finally {
            st.close()
        }
    }
    finally {
        conn.close()
    }
}
return []