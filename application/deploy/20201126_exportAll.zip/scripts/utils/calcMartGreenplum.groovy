import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def calcType = "F110MAIN"
def reportDate = "2020-04-01"
def scheduledTask = """
begin  perform nrlogs.logger_writelog(''Testing x jobs'', nrlogs.logger_log_notice()); end
"""*/


if (scheduledTask != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(calcType)  
    println(reportDate)       
    println(scheduledTask)    
    def conn = jc.connect()
    try {
        def st = conn.createStatement()
        try {
            def rs = st.execute("""select nrcore.dbms_scheduler_jobs_create(
  '${calcType}_${reportDate}_'||to_Char(now(), 'YYYY-MM-DD-HH24:MI:SS')::varchar,
   'do \$\$
   ${scheduledTask}
   \$\$ language plpgsql;'::text,
   'PL'::varchar,
   'ENABLED'::varchar,
   now() at time zone 'utc',
   null:: interval
);""")
        }
        finally {
            st.close()
        }
    }
    finally {
        conn.close()
    }
}
return []