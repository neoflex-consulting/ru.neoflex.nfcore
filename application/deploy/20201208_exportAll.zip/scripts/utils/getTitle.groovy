import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionTaxmon'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
def conn = jc.connect()
try {
    def st = conn.createStatement()
    //def on_date = '2019-12-31'
    try {
        def rs = st.executeQuery("""select '"'||full_name || '<br>' || 'ИНН: ' || inn ||', КПП: ' || kpp||'"' as str_value
  from (select string_value, param_name from dma.dm_branch_param_s where param_name in('FULL_NAME', 'INN', 'LOCATION_KPP') and to_date(${on_date},'yyyy-mm-dd') between actual_date and actual_end_date)
pivot(max(string_value) 
   for param_name in('FULL_NAME' as full_name, 'INN' as inn, 'LOCATION_KPP' as kpp))""")
        try {
            def rowData = []
            while (rs.next()) {
                def map = [:]
                def columnCount = rs.metaData.columnCount
                for (int i = 1; i <= columnCount; ++i) {
                    def object = rs.getObject(i)
                    map["${rs.metaData.getColumnName(i)}"] = (object == null ? null : object.toString())
                }
                rowData.add(map)
            }
            return rowData[0]["STR_VALUE"]
        }
        finally {
            rs.close()
        }
    }
    finally {
        st.close()
    }
}
finally {
    conn.close()
}