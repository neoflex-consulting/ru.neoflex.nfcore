import ru.neoflex.meta.emfgit.Transaction
import java.nio.file.Files
import java.io.File
import ru.neoflex.nfcore.base.components.SpringContext
import ru.neoflex.nfcore.masterdata.services.MasterdataProvider

def data = Transaction.getCurrent().getFileSystem().getPath("/masterdata/Person.json")
def is = Files.newInputStream(data)
try {
    def provider = SpringContext.getBean(MasterdataProvider.class)
    provider.execute("delete from Person")
    def exporter = provider.createExporter()
    print exporter.importJson(is)
}
finally {
    is.close()
}
