import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def testSetId = "1"
def testId = "1"
def inludeExcludeFlag = "V"*/

if (testSetId != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(testSetId)  
    println(testId)       
    println(inludeExcludeFlag)    
    def conn = jc.connect()
    try {
        def st = conn.createStatement()
        try {
            if (inludeExcludeFlag == "V") {
            def rs = st.execute("""update dqc.test_x_test_set txts 
   set is_active = 'N'
 where test_set_id = ${testSetId}
   and test_id = ${testId};""")
            } else {
            def rs = st.execute("""update dqc.test_x_test_set txts 
   set is_active = 'Y'
 where test_set_id = ${testSetId}
   and test_id = ${testId};""")
                
            }
        }
        finally {
            st.close()
        }
    }
    finally {
        conn.close()
    }
}
return []