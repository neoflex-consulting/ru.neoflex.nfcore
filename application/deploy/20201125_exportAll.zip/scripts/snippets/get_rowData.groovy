import ru.neoflex.nfcore.base.auth.AuthPackage
import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.utils.Utils


    def allUsers = Utils.findAllEClass(AuthPackage.Literals.USER)
    Object[] allColumnNames = AuthPackage.Literals.USER.eAllStructuralFeatures.name
    
    def rowData = []
    
    for (int i = 0; i < allUsers.size(); i++) {
    
        def map = [:]
        for (int j = 0; j <= allColumnNames.size() - 1; ++j) {
            def object = allUsers.get(i).contents.get(0)["${allColumnNames[j]}"]
            if ( object instanceof List ) {
                object = allUsers.get(i).contents.get(0)["${allColumnNames[j]}"]
                map["${allColumnNames[j]}"] = (object == null ? null : object.toString())
            }
            else {
                map["${allColumnNames[j]}"] = (object == null ? null : object.toString())
            }
        }
        rowData.add(map)
    }
    println("return row count: " + rowData.size())
    return rowData

        