import ru.neoflex.nfcore.base.services.Authorization;

Authorization.getUserName()