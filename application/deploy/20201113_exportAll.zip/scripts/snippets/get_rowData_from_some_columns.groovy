import ru.neoflex.nfcore.base.auth.AuthPackage
import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.utils.Utils

def allUsers = Utils.findAllEClass(AuthPackage.Literals.USER)
def size = allUsers.size()
def rowData = []

def resource = DocFinder.create(Context.current.store, DatasetPackage.Literals.DATASET_COMPONENT, [name: 'UsersDatasetComponent'])
                    .execute().resourceSet
                    def column = resource.resources[0].contents[0].column
                    
    
                for (int i = 0; i < size; i++) {
                    def map = [:]
                    for (int j = 0; j <= column.size() - 1; ++j) {
                        def object = allUsers.get(i).contents.get(0)["${column[j].name}"]
                        if ( object instanceof List && object.size() != 0) {
                            object = allUsers.get(i).contents.get(0)["${column[j].name}"].name
                            map["${column[j].name}"] = (object == null ? null : object.toString())
                        }
                        else {
                            map["${column[j].name}"] = (object == null ? null : object.toString())
                        }
                    }
                    rowData.add(map)
                }

    println("return row count: " + rowData.size())
    return rowData