import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def testNum = "10_DMA_CBF_0409115_0024"
def reportDate = "2020-03-31"
def branch = "000001"*/

if (testNum != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(testNum)  
    println(reportDate)       
    println(branch)    
    def conn = jc.connect()
    try {
        def st = conn.createStatement()
        try {
            def rs = st.execute("""SELECT dqc.data_quality_runTestByCode( 
'${testNum}',
date '${reportDate}',
'${branch}',
null
);""")
        }
        finally {
            st.close()
        }
    }
    finally {
        conn.close()
    }
}
return []