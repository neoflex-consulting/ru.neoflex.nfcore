
import ru.neoflex.nfcore.notification.NotificationPackage
import ru.neoflex.nfcore.notification.NotificationInstance
import ru.neoflex.nfcore.notification.NotificationStatus
import ru.neoflex.nfcore.application.ApplicationPackage
import ru.neoflex.nfcore.application.impl.CalendarExt
import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.utils.Utils
import java.text.SimpleDateFormat
import groovy.time.TimeCategory


//def reportName = "Ф110"
//def reportStatus = "PASS"
//def dateFromString = "2020-05-01"
//def dateToString = "2020-05-31"
println(reportName)
println(reportStatus)
println(dateFromString)
println(dateToString)

dateFromString = (dateFromString.size() <=10) ? dateFromString + " 00:00:00" : dateFromString
dateToString = (dateToString.size() <=10) ? dateToString + " 00:00:00" : dateToString

def dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
def dateFrom = dateFormat.parse(dateFromString)
def dateTo = dateFormat.parse(dateToString)

use(TimeCategory) { 
    dateFrom = dateFrom + 1.month
    dateTo = dateTo + 1.month
}

def newStatus = Utils.findEObject(NotificationPackage.Literals.NOTIFICATION_STATUS, reportStatus)

def notification = DocFinder.create(Context.current.store, NotificationPackage.Literals.NOTIFICATION, [name: reportName])
                .execute().resourceSet.resources[0]

def allNotificationInstances = DocFinder.create(Context.current.store)
    .getDependentResources(notification)
    .findAll {el -> el.contents[0] instanceof NotificationInstance && el.contents[0].calendarDate.after(dateFrom) && el.contents[0].calendarDate.before(dateTo)}

if (allNotificationInstances.size() == 0) {
    Utils.findAllEClass(ApplicationPackage.Literals.YEAR_BOOK).each{el->
        CalendarExt.createNotificationInstance(notification.contents[0], dateFormat.format(dateFrom), el.contents[0], Context.current.store.createResourceSet())}
    allNotificationInstances = DocFinder.create(Context.current.store)
        .getDependentResources(notification)
        .findAll {el -> el.contents[0] instanceof NotificationInstance && el.contents[0].calendarDate.after(dateFrom) && el.contents[0].calendarDate.before(dateTo)}
}

def notificationInstance= allNotificationInstances.collect{el -> el.contents[0]}[0] as NotificationInstance
def notificationInstanceRef = Context.current.store.getRef(allNotificationInstances)
notificationInstance.status.clear()
notificationInstance.status.add(newStatus)
Context.current.store.updateEObject(notificationInstanceRef,notificationInstance)
println(notificationInstance)
return []