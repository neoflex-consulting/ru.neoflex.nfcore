import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def reportDate = "2020-09-01"*/

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
def conn = jc.connect()
try {
    def st = conn.createStatement()
    try {
        def rs = st.executeQuery("""select count(*) as err_count,
 	   case 
 		 when count(*) = 0 then 'Ошибок на расчётную дату не обнаружено'
 		 else 'На отчетную дату обнаружены ошибки контроля качества данных в количестве: '||count(*)||''
 	   end as error_message,
 	   max(tr.oper_date) as report_date,
 	   max(tr.oper_date) as report_date_to
  from dqc.test t 
  join dqc.report_influence ri 
    on t.test_id = ri.test_id 
  join dqc.test_run tr 
    on t.test_id = tr.test_id 
  join dqc.problem p 
    on p.test_run_id = tr.test_run_id 
 where ri.report_id = 115
   and tr.oper_date = to_date('${reportDate}','YYYY-MM-DD') - 1""")
        try {
            def rowData = []
            while (rs.next()) {
                def map = [:]
                def columnCount = rs.metaData.columnCount
                for (int i = 1; i <= columnCount; ++i) {
                    def object = rs.getObject(i)
                    map["${rs.metaData.getColumnName(i)}"] = (object == null ? null : object.toString())
                }
                rowData.add(map)
            }
            print(rowData[0])
            return rowData[0]
        }
        finally {
            rs.close()
        }
    }
    finally {
        st.close()
    }
}
finally {
    conn.close()
}