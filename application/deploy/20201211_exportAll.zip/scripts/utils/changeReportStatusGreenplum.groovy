import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def dates = [[status_history:null, status_name:Рассчитан, status_code:CALC, on_date:2019-03-31, from_date:2019-03-01, change_status:2019-03-01/2019-03-31], [status_history:null, status_name:Проверено, status_code:CHECKED, on_date:2020-03-31, from_date:2020-03-01, change_status:2020-03-01/2020-03-31]]
def selectStatus = "status name"*/

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection

def status = selectStatus.replace('Расчет отчета за дату произведён','CALC')
.replace('Отчёт сдан в проверяющий орган','PASS')
.replace('Отчёт за дату проверен','CHECKED')

for (row in dates) {
	def conn = jc.connect()
	try {
	    def st = conn.createStatement()
	    try {
	        st.execute("""select nrlogs_pck_report_status.pSetStatus
	                                 (
	                                               i_on_date     :=to_date('${row["on_date"]}','YYYY-MM-DD'),
	                                               i_from_date   :=to_date('${row["from_date"]}','YYYY-MM-DD'),
	                                               i_report_id   :='F115',
	                                               i_report_type :='CB',
	                                               i_status_code :=cast('${status }' as varchar(256)),
	                                               i_apex_user   :='ADMIN'
	                                 );""")
	    }
	    finally {
	        st.close()
	    }
	}
	finally {
	    conn.close()
	}
}
return []