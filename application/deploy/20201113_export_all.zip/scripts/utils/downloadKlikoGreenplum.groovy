import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

def event_record_id = "68"

def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectionNRStudio_nrtest'])
        .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
def conn = jc.connect()
try {
    def st = conn.createStatement()
    try {
        def rs = st.executeQuery("""SELECT clob_data as clob_data
  from nrlogs.lg_fd_data_file f
 where event_record_id = ${event_record_id}""")
        try {
            def rowData = []
            while (rs.next()) {
                def map = [:]
                def columnCount = rs.metaData.columnCount
                for (int i = 1; i <= columnCount; ++i) {
                    def object = rs.getObject(i)
                    map["${rs.metaData.getColumnName(i)}"] = (object == null ? null : object.toString())
                }
                rowData.add(map)
            }
            return [rowData[0]["clob_data"]]
        }
        finally {
            rs.close()
        }
    }
    finally {
        st.close()
    }
}
finally {
    conn.close()
}