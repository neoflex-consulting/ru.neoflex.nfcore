
import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.notification.NotificationPackage
import ru.neoflex.nfcore.notification.NotificationInstance
import ru.neoflex.nfcore.notification.NotificationStatus
import ru.neoflex.nfcore.application.impl.CalendarExt
import ru.neoflex.nfcore.utils.Utils
import ru.neoflex.nfcore.notification.NotificationFactory
import java.text.SimpleDateFormat
import ru.neoflex.nfcore.application.ApplicationPackage
import ru.neoflex.nfcore.application.impl.CalendarExt


def dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
def dateFrom = dateFormat.parse("2020-06-01T17:00:00")
def dateTo = dateFormat.parse("2020-06-31T17:00:00")
def reportName = "Ф110"
def reportStatus = "PASS"

def statusesEnum = ["PASS":"Отчёт сдан в проверяющий орган","CHECKED":"Отчёт за дату проверен","CALC":"Расчет отчета за дату произведён"]
def newStatus = Utils.findEObject(NotificationPackage.Literals.NOTIFICATION_STATUS, statusesEnum[reportStatus])

def notification = DocFinder.create(Context.current.store, NotificationPackage.Literals.NOTIFICATION, [name: reportName])
                .execute().resourceSet.resources[0]

def allNotificationInstances = DocFinder.create(Context.current.store)
    .getDependentResources(notification)
    .findAll {el -> el.contents[0] instanceof NotificationInstance && el.contents[0].calendarDate.after(dateFrom) && el.contents[0].calendarDate.before(dateTo)}

if (allNotificationInstances.size() == 0) {
    def yearBook = Utils.findAllEClass(ApplicationPackage.Literals.YEAR_BOOK)[2].contents[0]
    CalendarExt.createNotificationInstance(notification.contents[0], "Wed Jun 01 2020 00:00:00 GMT+0400 (Самарское стандартное время)", yearBook, Context.current.store.createResourceSet())
    println(notification.contents[0])
    allNotificationInstances = DocFinder.create(Context.current.store)
        .getDependentResources(notification)
        .findAll {el -> el.contents[0] instanceof NotificationInstance && el.contents[0].calendarDate.after(dateFrom) && el.contents[0].calendarDate.before(dateTo)}
}

def notificationInstance= allNotificationInstances.collect{el -> el.contents[0]}[0] as NotificationInstance
def notificationInstanceRef = Context.current.store.getRef(allNotificationInstances)
notificationInstance.status.clear()
notificationInstance.status.add(newStatus)
Context.current.store.updateEObject(notificationInstanceRef,notificationInstance)
println(notificationInstance)