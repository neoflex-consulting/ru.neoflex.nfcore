import ru.neoflex.nfcore.base.services.Context
import ru.neoflex.nfcore.base.util.DocFinder
import ru.neoflex.nfcore.dataset.DatasetPackage
import ru.neoflex.nfcore.dataset.JdbcConnection

/*def deletedRid = "123,456,789"
def schema = "DMA"
def table = "DM_F135_INCLUDING_FORCE_S"*/

if (deletedRid != "") {
    def jc = DocFinder.create(Context.current.store, DatasetPackage.Literals.JDBC_CONNECTION, [name: 'JdbcConnectiontSCI12'])
            .execute().resourceSet.resources.get(0).contents.get(0) as JdbcConnection
            
    println(schema)  
    println(table)       
    for (rid in deletedRid.split(',')) {
        println(rid)    
        def conn = jc.connect()
        try {
            def st = conn.createStatement()
            try {
                def rs = st.execute("""declare
      v number;
    begin
      v := nrlogs.pck_data_changes.fRecoverDeletedData('${schema}','${table}', '${rid}');
    end;""")
            }
            finally {
                st.close()
            }
        }
        finally {
            conn.close()
        }
    }
}
return []